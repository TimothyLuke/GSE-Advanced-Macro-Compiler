# Menu.lua — per-file detail

**File:** `GSE_GUI/Menu.lua`
**Change type:** edit (1 hunk)
**Net effect:** the GSE toolbar/menu frame opts out of GSE's post-scale clamp,
fixing its scale-down "left jump."

---

## The hunk

The toolbar/menu frame (`GSEMenuFrame`) already self-clamps via Blizzard's
`SetClampedToScreen(true)`. The change sets the new opt-out flag immediately
after, so GSE's own `ClampFrameToScreen` (called at the end of
`GSE.ApplyScaleToFrame`) is skipped for this frame:

```lua
frame:SetClampedToScreen(true)
-- Self-clamps via SetClampedToScreen above, so skip GSE's post-scale clamp,
-- which would permanently re-anchor the frame and cause a scale-down "left jump".
frame.GSESkipScaleClamp = true
```

## Why

GSE's clamp permanently re-anchors a frame that grows past a screen edge. Combined
with the centred rescale, that re-anchor pulled the toolbar left when scaling
down. Relying on Blizzard's `SetClampedToScreen` instead keeps the toolbar
on-screen without the jump. The centred-rescale part of `ApplyScaleToFrame` still
runs for this frame — only the redundant GSE clamp is skipped.

---

## Verification specific to this file

- `loadfile("Menu.lua")` parses with no error.
- With the flag set, the scale-semantics model shows `ClampFrameToScreen` is not
  called for this frame, while the centred rescale still applies.
- The combined diff reproduces this file byte-for-byte; CRLF preserved.
