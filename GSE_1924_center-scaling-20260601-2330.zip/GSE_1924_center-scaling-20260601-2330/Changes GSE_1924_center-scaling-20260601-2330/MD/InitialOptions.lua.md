# InitialOptions.lua — per-file detail

**File:** `GSE/API/InitialOptions.lua`
**Change type:** edit (1 hunk, in `GSE.ApplyScaleToFrame`)
**Net effect:** GSE windows scale about their centre instead of drifting
right-on-grow / left-on-shrink, and self-clamping frames can skip GSE's
post-scale clamp.

---

## The function

`GSE.ApplyScaleToFrame(frame, scale)` is the single routine every scaled GSE
window goes through (`RegisterUIScaleFrame`, `ApplyUIScale`,
`ApplyMenuScaleToFrame`, `ApplyMenuUIScale` all call it). It applies the new
scale and tries to keep the window centred.

## Why it drifted

`frame:GetCenter()` returns coordinates in the frame's **own** coordinate space —
absolute screen pixels divided by the frame's effective scale. The old code
captured the centre at the **old** scale, then re-applied those raw numbers via
`GSE.SetFrameScreenPoint(frame, "CENTER", centerX, centerY)` **after** `SetScale`.
`SetFrameScreenPoint` targets the frame's coordinate space, which is now the
**new** scale, so the absolute centre ended up at `oldCenter × (newScale / oldScale)`
— moving right/up when scaling up and left/down when scaling down.

## The hunk

Before `SetScale`, convert the centre to absolute screen pixels with the **old**
effective scale (a point that must not move):

```lua
local absX, absY
if preserveCenter then
    local centerX, centerY = frame:GetCenter()
    preserveCenter = centerX and centerY and UIParent
    if preserveCenter then
        local oldEffective = (frame.GetEffectiveScale and frame:GetEffectiveScale()) or 1
        if not oldEffective or oldEffective <= 0 then oldEffective = 1 end
        absX, absY = centerX * oldEffective, centerY * oldEffective
    end
end

frame:SetScale(scale)
```

After `SetScale`, convert that absolute centre back into the frame's **new** local
units and re-anchor; gate GSE's clamp on the new opt-out flag:

```lua
if preserveCenter then
    local newEffective = (frame.GetEffectiveScale and frame:GetEffectiveScale()) or 1
    if not newEffective or newEffective <= 0 then newEffective = 1 end
    GSE.SetFrameScreenPoint(frame, "CENTER", absX / newEffective, absY / newEffective)
    if not frame.GSESkipScaleClamp then
        GSE.ClampFrameToScreen(frame)
    end
end
```

Because `absX/absY` are absolute pixels, dividing by the new effective scale yields
the frame-local centre that places the window's absolute centre exactly where it
was — so it scales about its centre.

## Why `GSESkipScaleClamp`

`GSE.ClampFrameToScreen` permanently re-anchors a frame that grew past a screen
edge. For frames that already use Blizzard's `SetClampedToScreen` (the
toolbar/menu), that extra re-anchor produced a scale-down "left jump." The new
`GSESkipScaleClamp` flag lets such frames opt out of GSE's clamp while keeping the
centred rescale. The pre-existing `GSESkipScaleRecenter` flag (skip recentre
entirely) is untouched and independent.

---

## Verification specific to this file

- `loadfile("InitialOptions.lua")` parses with no error.
- Scale-semantics model running the real old/new logic: new keeps the absolute
  centre fixed across grow/shrink; old drifts right/left as reported.
- `GSESkipScaleClamp` gating confirmed (clamp called when false, skipped when true).
- The combined diff reproduces this file byte-for-byte; CRLF preserved.
