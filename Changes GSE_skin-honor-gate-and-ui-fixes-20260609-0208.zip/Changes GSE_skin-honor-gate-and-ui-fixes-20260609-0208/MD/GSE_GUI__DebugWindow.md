# GSE_GUI/DebugWindow.lua

**Role in this changeset:** Reworks the Debugger's docked side-window chrome (strata/level/clip/border layering), removes the redundant side-window close buttons, keeps attached windows synced on group-move, and adds a skin-refresh path so the Debugger repaints on show and on skin toggle.

**Lines:** 4994 → 5039 (+45)
**Hunks:** 12
**Severity:** High (frame-strata/clip layering and a new on-show skin-refresh entry point)

---

## What changed

### 1. `EnsureDebuggerSideCloseButton` no longer creates an [X] (line ~585)
The whole block that created/positioned/wired `frame.CloseButton` on the side
windows was replaced with:
```lua
-- Side windows no longer carry their own [X] close button...
if frame.CloseButton then frame.CloseButton:Hide() end
```
Rationale: the side [X] could draw *behind* the panel depending on
strata/level, and the side windows are toggled from the main Debugger's
Stats/Hardware buttons anyway.

### 2. `SetDebuggerSideCloseButtonVisible` neutered (line ~609)
Now just keeps any pre-existing side [X] hidden — no creation, no show.

### 3. `SyncDebuggerSideSkinLayers` — attached vs detached border offset (line ~609)
Adds an `attached` check and a `borderOffset`:
```lua
local borderOffset = attached and 1 or 100
syncLayer(frame.GSEElvUIOuterShell, 0)
syncLayer(frame.GSEElvUIOuterClassBorder, borderOffset)
syncLayer(frame.GSENormalAccentBorderOverlay, borderOffset)
```
When **attached**, the class-colour border is synced **one level above** the
side window's own dark `GSEElvUIOuterShell` border (offset 1, not 0) so the
coloured border draws over the dark one on every edge — previously the outer
(free) edges showed the dark shell border instead of the class colour. The
side frame sits at `main-2`, so offset 1 lands the border at `main-1`: above
the shell, still below the main window's own border at the 4px docking
overlap. **Detached** windows keep the `+100` lift so their border still draws
above other UI.

### 4. `RaiseDebuggerSideChrome` — sit behind main, don't clip, hide [X] (line ~664)
Three coordinated changes for attached windows:
- **Level:** `SetFrameLevel(DebugFrame:GetFrameLevel())` → `math.max(0, (DebugFrame:GetFrameLevel() or 0) - 2)`, and `SetToplevel(true)`/`Raise()` removed, replaced with `SetToplevel(false)`. The side now sits **two below** the main so the main's chrome wins at the docking seam, and it does **not** bump itself to front on click.
- **Clip:** `SetClipsChildren(true)` → `SetClipsChildren(false)`. A true clip was cutting off the **top** border band (`GSEElvUIOuterClassBorder` sits at/above the frame's top edge) on the side windows. Inner content frames clip themselves, so rows stay contained with the outer clip off.
- **[X]:** any existing side close button is forced hidden.

### 5 & 6. Group-move re-sync (lines ~911 and ~1082)
Both the `OnDragStop` handler and the title-bar mouse-up handler now call:
```lua
if self.UpdateDebuggerWindowLevels then self.UpdateDebuggerWindowLevels() end
```
so attached side windows keep the main's strata/level after the group is
moved together.

### 7. Cache the main window's title + close button (line ~1163)
```lua
DebugFrame.GSEWindowTitle = title
DebugFrame.GSEWindowCloseButton = closeButton
```
Stored so the new `RefreshDebuggerSkin` can re-style the main window later.

### 8 & 9. Side widgets: don't clip + cache their titles (lines ~2002/~2051 and ~2745/~2783)
`statsWidget` and `hardwareWidget` both switch `SetClipsChildren(true) → false`
(same top-border-clipping fix as hunk 4) and each stores
`<widget>.GSEWindowTitle = <title>` for the refresh path.

### 10. Stats body right edge in 2px (line ~2574)
`statsScrollBackground` `BOTTOMRIGHT` x-offset `-12 → -14`. The header, rows
scroll frame, and column area all anchor to this edge, so they follow in by
2px. Left side and window width unchanged. Cosmetic.

### 11. **New `GSE.RefreshDebuggerSkin()`** (line ~4952)
A function that re-applies window chrome to the Debugger and both side windows
so they track the current skin (Native / Modern / external provider):
```lua
function GSE.RefreshDebuggerSkin()
    DebugFrame.ApplyEditorWindowStyle(DebugFrame, DebugFrame.GSEWindowTitle, DebugFrame.GSEWindowCloseButton)
    if statsWidget then DebugFrame.ApplyEditorWindowStyle(statsWidget, statsWidget.GSEWindowTitle) end
    if hardwareWidget then DebugFrame.ApplyEditorWindowStyle(hardwareWidget, hardwareWidget.GSEWindowTitle) end
    if DebugFrame.RaiseDebuggerControls then DebugFrame.RaiseDebuggerControls() end
    if DebugFrame.RaiseDebuggerSideChrome then
        if statsWidget then DebugFrame.RaiseDebuggerSideChrome(statsWidget) end
        if hardwareWidget then DebugFrame.RaiseDebuggerSideChrome(hardwareWidget) end
    end
    RefreshDebuggerTitleChrome()
end
```
The three `ApplyEditorWindowStyle` calls had only ever run once at file-load,
so a skin change afterwards left the Debugger painted in whatever skin was
active at load. This re-applies on demand. It also re-raises the main controls
(close + minimize) to `frame+500` and `Raise()`s them, because
`ApplyEditorWindowStyle` re-seats the close button at only `frame+20`.

### 12. Call the refresh on show (line ~4988)
`GSE.GUIShowDebugWindow()` and the Debugger's `OnShow` hook both swap
`RefreshDebuggerTitleChrome()` → `GSE.RefreshDebuggerSkin()`, so the window
repaints in the current skin every time it is shown (including right after a
Native/Modern toggle + the reload the toggle now prompts for).

## Why it matters in current WoW

- **Frame strata/level/clip** are the classic source of "border clipped",
  "close button behind the panel", and "docked window floats in front of its
  parent" bugs. Hunks 3/4/8 fix all three for the docked Stats/Hardware
  windows by (a) seating the side two levels below the main, (b) lifting only
  the class border one level so it paints over the dark shell, and (c) turning
  off the outer clip that was eating the top border.
- **Hunk 11/12** close the same skin-staleness gap as the NativeUI OnShow fix,
  but for the Debugger family specifically: previously the Debugger kept its
  load-time skin forever.
- Removing the side [X] (hunks 1/2/4) eliminates a control that could render
  behind the panel — a clean simplification, with the toggle still available
  from the main window's Stats/Hardware buttons.

## API / policy notes

- All layering uses `SetFrameStrata` / `SetFrameLevel` / `SetToplevel` /
  `SetClipsChildren` / `Raise` — standard widget API, current on Retail.
- `GSE.RefreshDebuggerSkin` calls are all nil-guarded
  (`if DebugFrame.RaiseDebuggerControls then ...`), and the callees
  `RaiseDebuggerControls` (line 4519) and `RaiseDebuggerSideChrome` are
  defined in this file — verified.
- No secure/protected frames involved; the Debugger is a plain insecure
  window, so no taint/combat-lockdown concern.

## Verification

- `luac5.1 -p GSE_GUI/DebugWindow.lua` → **PASS**
- `luacheck` → **24 warnings, identical to base** (no new issues from this diff)
- Confirmed `GSE.RefreshDebuggerSkin` is defined (line 4961) and that the
  cached fields it reads (`GSEWindowTitle`, `GSEWindowCloseButton`) are set
  at the hunks above before any show can occur.

## Remaining risk / notes

- This is the file most dependent on **in-game visual verification** — strata
  math and clip behaviour can't be fully proven statically. Test matrix:
  1. Open Debugger, toggle Stats and Hardware on/off — side windows dock
     behind the main at the seam, no top-border clipping, no stray [X].
  2. Drag the main window by its title — attached side windows follow and stay
     behind (group-move re-sync).
  3. Detach a side window — its border lifts (+100) and draws above other UI.
  4. Toggle Native↔Modern, `/reload`, reopen Debugger — chrome matches the
     selected skin; the main [X] is on top, not behind the frame.
- The two side-widget `if statsWidget`/`if hardwareWidget` guards in
  `RefreshDebuggerSkin` assume those upvalues are in scope at definition time;
  they are file-scope locals created earlier in the file, so this holds.
