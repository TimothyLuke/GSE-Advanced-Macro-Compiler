# GSE_GUI/Editor.lua

**Role in this changeset:** Honor-gates the keyword label colour and supplies the resize-drag `skipTreeRefresh` gating that the NativeUI tree change depends on. Plus two small layout nudges.

**Lines:** 7638 → 7657 (+19)
**Hunks:** 4
**Severity:** Medium (the resize gate is the other half of a performance fix; the rest is cosmetic + honor-gate)

---

## What changed

### Hunk 1 — `keywordColor()` honor-gated (line ~11)
The keyword/label accent previously forced neutral white whenever
EllesmereUI was loaded. It now only does so in Modern mode:

```lua
if (not GSE.ShouldHonorExternalSkin or GSE.ShouldHonorExternalSkin())
    and GSE.IsEllesmereUILoaded and GSE.IsEllesmereUILoaded() then
    return 1, 1, 1, 1
end
return GSE.GUIGetColour(GSEOptions.KEYWORD)
```

In Native mode, labels keep their KEYWORD colour even with EUI installed.
(Note the existing comment correctly warns that `GUIGetColour` returns
`r, g, b` as **separate values**, so this branch must return multiple values,
not a table.)

### Hunk 2 — checkbox text baseline +1px (line ~402)
`BumpCheckBoxTextUp` anchor changed from `("LEFT", frame, "RIGHT", 0, 0)` to
`(..., 0, 1)` — nudges checkbox label text up one pixel to sit on the box's
vertical centre. Cosmetic.

### Hunk 3 — repeat-row flow offset (line ~5226)
`typerow:SetFlowOffset(0, -4)` → `SetFlowOffset(0, 16)`. Repositions the
repeat/type row within its flow container. Cosmetic/layout.

### Hunk 4 — resize-drag tree gating (line ~6997)
Two new callbacks bracket the resize so the tree container's `skipTreeRefresh`
flag is set during the drag and cleared at the end:

```lua
editframe:SetCallback("OnResizeStart", function()
    if editframe.treeContainer then
        editframe.treeContainer.skipTreeRefresh = true
    end
end)

editframe:SetCallback("OnResizeStop", function()
    if editframe.treeContainer then
        editframe.treeContainer.skipTreeRefresh = nil   -- clear FIRST
    end
    if editframe.resizeLayoutPending or editframe.resizeLayoutDirty then
        FinishResizeLayout()
    end
end)
```

During the drag the per-tick `DoLayout` only re-flows the (cheap) action rows;
the expensive full sequence-tree rebuild is suppressed and runs exactly once
at the end via `FinishResizeLayout`. The flag is cleared **before**
`FinishResizeLayout` so that final pass does a proper full refresh.

## Why it matters in current WoW

This is the producer side of the `skipTreeRefresh` contract that
`NativeUI.lua`'s `OnWidthSet`/`OnHeightSet` consume. Without it, dragging the
editor edge rebuilt the entire sequence tree on every throttled tick — the
dominant cost in the resize loop and exactly the per-frame churn the release
checklist flags for the resize pump.

The `keywordColor()` gate is part of the cross-file honor-gate sweep: it stops
EllesmereUI's white from overriding the user's chosen KEYWORD colour when they
asked for the Native skin.

## API / policy notes

- `SetCallback("OnResizeStart"/"OnResizeStop", ...)` is the AceGUI-style
  widget callback surface GSE already uses; no new dependency.
- All cosmetic offsets are plain `SetPoint`/`SetFlowOffset` values — portable
  across clients.
- No secure/taint surface.

## Verification

- `luac5.1 -p GSE_GUI/Editor.lua` → **PASS**
- `luacheck` → **87 warnings, identical to base** (no new issues from this diff)
- Confirmed the consumer side (`skipTreeRefresh` checks in NativeUI
  `OnWidthSet`/`OnHeightSet`) is present and reads the same field this hunk sets.

## Remaining risk / notes

- The gate relies on `OnResizeStop` always firing to clear `skipTreeRefresh`.
  If a drag could end without `OnResizeStop` (e.g. frame hidden mid-drag), the
  tree would stay in skip mode until the next resize. Low likelihood given the
  AceGUI resize lifecycle, but worth a glance during in-game testing — hide the
  editor mid-resize and confirm the tree still refreshes on next open.
- Hunks 2 and 3 are visual nudges; eyeball checkbox label alignment and the
  repeat-row position after `/reload`.
