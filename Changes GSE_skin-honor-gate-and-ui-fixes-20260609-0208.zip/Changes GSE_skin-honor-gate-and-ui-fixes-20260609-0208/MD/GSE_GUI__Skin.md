# GSE_GUI/Skin.lua

**Role in this changeset:** The dispatcher. This is where the honor-gate actually pins the provider to no-op in Native mode, making the whole GUI native in one move.

**Lines:** 482 → 519 (+37)
**Hunks:** 5
**Severity:** Medium–High (changes how every widget in the GUI decides to paint itself)

---

## What changed

### Hunk 1 & 2 — documentation + the gate in `selectProvider()` (lines ~7 and ~399)

The provider-selection function now consults the honor-gate before it
considers any external provider:

```lua
local function selectProvider()
    local provider
    if GSE.ShouldHonorExternalSkin and not GSE.ShouldHonorExternalSkin() then
        provider = makeNoopProvider()
    else
        provider = makeElvUIProvider() or makeEllesmereUIProvider() or makeNoopProvider()
    end
    for k, v in pairs(provider) do GSE.Skin[k] = v end
    GSE.Skin.providerName = provider.name
end
```

Because every downstream paint decision keys off `GSE.Skin.providerName`
(NativeUI's `hasExternalSkinProvider` / `IsExternalProviderActive`, the
`Paint*` helpers), pinning the provider to `"none"` here makes the entire
GUI render Blizzard-native in a single move — no per-widget edits required.

The header comment was expanded to state "USER CHOICE COMES FIRST" and that
the priority list (ElvUI → EllesmereUI → no-op) only applies in Modern mode.

### Hunk 3 — new public `GSE.Skin.Reselect()` (line ~399)

```lua
function GSE.Skin.Reselect()
    selectProvider()
end
```

A public re-entry so the Native/Modern toggle can re-pick the provider live.
Newly opened windows then read the correct `providerName` immediately;
already-open windows still need a `/reload` for a full repaint (the same
caveat the menu-logo swap already carried).

### Hunks 4, 5, 6 — `PaintAccentText`, `PaintBodyText`, `PaintAccentBorder` (lines ~453, ~471, ~486)

All three painters previously read EllesmereUI's palette
(`ELLESMERE_GREEN`, `TEXT_WHITE`, `BORDER_COLOR`) unconditionally whenever the
global table existed. They are now wrapped in:

```lua
if GSE.Skin.IsExternalProviderActive() then
    ... borrow EllesmereUI's colour ...
end
-- otherwise fall straight through to the GSE fallback colour
```

In Native mode `providerName` is `"none"`, so `IsExternalProviderActive()`
returns false and the painters never touch EUI's palette — they use the GSE
fallback colours passed in by the caller.

## Why it matters in current WoW

This is the file that makes the honor-gate *real*. The foundation in
`InitialOptions.lua` is just a boolean; here it is consumed at the one
chokepoint (`selectProvider`) plus the three colour painters. Without the
painter guards, even with the provider pinned to no-op, any direct
`PaintAccentText`/etc. call would still have leaked EllesmereUI's green/white
into a Native-skin UI.

## API / policy notes

- `GSE.Skin.IsExternalProviderActive()` is defined in this same file (line 449),
  so the painter guards have a guaranteed callee.
- Reads of `_G.EllesmereUI` are type-checked (`type(EUI) == "table"`) before
  use — correct defensive pattern; no change there.
- No secure/taint surface: this only sets `SetTextColor` / `SetBackdropBorderColor`
  on GSE's own (insecure) widgets.

## Verification

- `luac5.1 -p GSE_GUI/Skin.lua` → **PASS**
- `luacheck` → **1 warning, identical to base** (pre-existing; not introduced here)
- Confirmed `selectProvider` is still called at load (the no-op init block
  immediately below it is unchanged) and that `Reselect` is exported on the
  `GSE.Skin` table.

## Remaining risk / notes

- `GSE.Skin.Reselect()` is now public but I did **not** see a call site for it
  added in this build's `Options.lua` skin toggle (that path uses the reload
  prompt instead). It is harmless dead-ready API — available for a future
  live-swap path — but if "live reselect without reload" was the intent, the
  Options toggle would need to call `GSE.Skin.Reselect()` (and `GSE.RefreshDebuggerSkin()`)
  before/instead of prompting. Flagging so it is a deliberate choice, not an omission.
