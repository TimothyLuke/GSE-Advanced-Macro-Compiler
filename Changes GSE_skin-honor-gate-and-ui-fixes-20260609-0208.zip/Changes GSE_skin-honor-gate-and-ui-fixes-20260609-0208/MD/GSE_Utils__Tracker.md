# GSE_Utils/Tracker.lua

**Role in this changeset:** Fixes a genuine boolean-logic bug that made the tracker-lock toggle one-way (could only ever unlock, never re-lock).

**Lines:** 3722 → 3734 (+12)
**Hunks:** 1
**Severity:** Medium (functional logic bug in a user-facing toggle; not a crash, but the feature was half-broken)

---

## What changed

`GSE.SequenceIconToggleTrackerLocked()` (bound to Alt+RightClick on any of the
three tracker frames) read the current lock state through the classic
`a and b() or c` ternary substitute:

**Before:**
```lua
local currentlyLocked = GSE.SequenceIconAreLinkedTrackerFramesLocked and
                            GSE.SequenceIconAreLinkedTrackerFramesLocked() or true
```

**After:**
```lua
local currentlyLocked = true
if GSE.SequenceIconAreLinkedTrackerFramesLocked then
    currentlyLocked = GSE.SequenceIconAreLinkedTrackerFramesLocked() == true
end
local newLocked = not currentlyLocked
```

## Why it matters in current WoW

This is the textbook failure mode of `a and b() or c` as a ternary: it breaks
when `b()` can legitimately return **`false`**.

When the tracker is **unlocked**, `SequenceIconAreLinkedTrackerFramesLocked()`
correctly returns `false`. In the old expression that became:

```
(accessor_is_truthy) and false  -> false
false or true                   -> true
```

So `currentlyLocked` was pinned to `true` on **every** call regardless of the
real state. `newLocked = not currentlyLocked` was therefore `false` every
time — meaning Alt+RightClick could only ever **unlock**; re-locking the
tracker was impossible.

The rewrite computes the state directly and nil-safely: default to `true`
(safe assumption), and only override it when the accessor exists, using an
explicit `== true` comparison so a real `false` is preserved instead of being
masked by an `or`-default.

## API / policy notes

- Pure Lua control-flow fix; no Blizzard API surface, no secure/taint concern.
  The downstream `GSE.SequenceIconSetLinkedTrackerLockState(newLocked)` call is
  unchanged.
- The `== true` normalisation also hardens against the accessor returning a
  truthy non-boolean (e.g. a number) — `newLocked` stays a clean boolean.

## Verification

- `luac5.1 -p GSE_Utils/Tracker.lua` → **PASS**
- `luacheck` → **11 warnings, identical to base** (no new issues from this diff)
- Logic walk-through confirms both directions now work:
  - unlocked (`false`) → `currentlyLocked=false` → `newLocked=true` → locks ✔
  - locked (`true`) → `currentlyLocked=true` → `newLocked=false` → unlocks ✔

## Remaining risk / notes

- **Needs in-game verification:** Alt+RightClick a tracker frame repeatedly and
  confirm it now toggles **both** ways (lock → unlock → lock). Before this fix
  it would have appeared "stuck unlocked".
- Behavioural change is intentional and strictly a fix; nothing else in the
  function was altered.
