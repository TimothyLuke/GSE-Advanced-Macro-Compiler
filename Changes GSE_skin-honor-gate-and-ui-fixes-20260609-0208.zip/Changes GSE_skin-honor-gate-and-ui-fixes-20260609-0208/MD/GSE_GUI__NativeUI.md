# GSE_GUI/NativeUI.lua

**Role in this changeset:** The most functionally dense file in the set — seven distinct fixes spanning a real nil-call bug, two resize-performance optimisations, a skin-on-show repaint fix, and a Native-skin visual cleanup.

**Lines:** 6863 → 6853 (−10 net; the removed accent-border block is larger than the additions)
**Hunks:** 8
**Severity:** High (one crash-class bug + two performance gates + a visible-state correctness fix)

---

## What changed (by hunk)

### 1. Class-border band top edge nudged up 1px (line ~1005)
The band's `TOPLEFT` y-offset went `0 → 1`. `BOTTOMRIGHT` is unchanged, so
only the top border line moves up one pixel. Pure cosmetic alignment.

### 2. **Native-skin outer class-colour border REMOVED** (line ~1054)
The entire `getNormalAccentColor(1)` branch that built the 4-side
`GSENormalAccentBorderOverlay` (top/bottom/left/right textures) was deleted.
The function now just hides any previously-created border:

```lua
if frame.GSENormalAccentOuterBorder then
    frame.GSENormalAccentOuterBorder:Hide()
end
```

Rationale (per the inline comment): the coloured outline didn't sit well
against Blizzard's native frame chrome. The class/custom accent colour still
applies to button/checkbox text and the slim scrollbar elsewhere; only the
window *outline* is gone. The Modern skin's own borders (via
`applyElvUIWindowSkin`) are unaffected.

### 3. OnShow now re-applies the **full** skin, not just the accent border (line ~1785)
The window `OnShow` hook previously re-ran only `applyNormalAccentWindowSkin`.
It now re-runs the complete skin path on every show:

```lua
if self.GSEUsesBlizzardPanelTemplate then
    styleBlizzardPanelFrame(self)
else
    skinPanel(self)
end
applyElvUIWindowSkin(self, self.GSESkinTitleBar or self.TitleContainer or self, self.GSESkinTitle or self.TitleText)
applyNormalAccentWindowSkin(self)
```

This makes a frame that was created/cached under one skin repaint with the
**current** skin when shown again — e.g. the reload-confirm prompt that
appears immediately after the Native/Modern toggle.

### 4. Remember the titleBar/title used to skin a frame (line ~1885)
```lua
frame.GSESkinTitleBar = titleBar
frame.GSESkinTitle = title
```
Stored so the OnShow hook (hunk 3) can re-apply the full skin against the
correct title widgets after a swap made while the frame was hidden.

### 5. Resize pump — whole-pixel coalesce (lines ~2039, ~2049, ~2064)
A `lastResizeW, lastResizeH` pair was added. On each `OnUpdate` tick during a
drag, the rendered size is floored to whole pixels and compared to the last
tick:

```lua
local rw = math.floor(w + 0.5)
local rh = math.floor(h + 0.5)
if rw == lastResizeW and rh == lastResizeH then
    return  -- no change this tick; skip the relayout
end
lastResizeW, lastResizeH = rw, rh
```

The pair is reset to `nil` on mouse-down. This skips the `widget:DoLayout()`
call when the cursor is moving sub-pixel or merely hovering — eliminating
redundant relayouts in the throttled resize loop.

### 6. **`origToggle` nil-upvalue bug fixed** (line ~5172)
```lua
origToggle = toggleNavWindow      -- capture the real impl FIRST
toggleNavWindow = function()
    origToggle()
    updateChevron()
    ...
end
```
`origToggle` is a file-scope local declared as `local origToggle = nil` at
line 11. It was **never assigned** before the wrapper was installed, so the
wrapper called a nil upvalue and the chevron click threw *before* the tree
could toggle. Capturing the real implementation first fixes the click.

### 7. Skip nav-window/tree work during a resize drag (lines ~5606, ~5611)
`OnWidthSet` now guards the nav-window text-measuring pass, and `OnHeightSet`
guards the full tree rebuild, both behind `self.skipTreeRefresh`:

```lua
if navVisible and not self.skipTreeRefresh then refreshNavWindow() end
...
if not self.skipTreeRefresh then self:RefreshTree() end
```

The Editor sets `skipTreeRefresh` on `OnResizeStart` and clears it on
`OnResizeStop` (see the companion change in `Editor.lua`), so the expensive
tree rebuild runs **once** at the end of the drag via `FinishResizeLayout`
instead of on every tick.

## Why it matters in current WoW

- **Hunk 6** is the highest-impact: a nil call in a click handler is a hard
  Lua error that BugSack would surface and that broke the chevron/tree toggle
  entirely.
- **Hunks 5 & 7** directly address per-frame work in the resize `OnUpdate`
  pump — the exact "no per-frame relayout / keep the pump throttled" concern
  in the release checklist. Together they cut the work per tick from
  "relayout + nav remeasure + full tree rebuild" down to (at most) one
  relayout, and skip even that when the pixel size is unchanged.
- **Hunks 3 & 4** make the skin-toggle reload prompt paint in the *new* skin,
  closing the visual gap where the confirm dialog appeared in the old skin.

## API / policy notes

- All edits operate on GSE's own insecure frames; no protected-frame
  show/hide/move and no `SetAttribute` — no taint surface.
- `StartSizing`/`StopMovingOrSizing`, `math.floor`, `HookScript("OnShow")`,
  and `CreateFrame` usage are all current and client-portable.
- `skipTreeRefresh` is a plain field on the tree container; the cross-file
  contract with `Editor.lua` is field-based, not API-based, so no version risk.

## Verification

- `luac5.1 -p GSE_GUI/NativeUI.lua` → **PASS**
- `luacheck` → **57 warnings, identical to base** — importantly, the
  `origToggle = toggleNavWindow` assignment did **not** add an
  accidental-global warning, confirming `origToggle` is a real declared
  upvalue (verified directly at line 11).
- Confirmed `GSE.GUIConfirmReloadUI` (referenced by the Options toggle that
  drives the OnShow repaint scenario) is defined at line 6182.

## Remaining risk / notes

- **Chevron-wrap idempotency (minor):** the fix assigns `origToggle = toggleNavWindow`
  then reassigns `toggleNavWindow`. If the enclosing setup function can run a
  second time in one session, `origToggle` would capture the *already-wrapped*
  function, double-wrapping it. The fix is strictly better than the prior
  nil-call crash, but if re-entry is possible, guard with
  `if not origToggle then origToggle = toggleNavWindow end`. **Needs in-game
  check** that the tree setup runs once per session.
- **Needs in-game verification:** resize the editor and confirm it is smooth
  with no tree flicker mid-drag, and that the final layout is correct on
  mouse-up (headline UX item).
