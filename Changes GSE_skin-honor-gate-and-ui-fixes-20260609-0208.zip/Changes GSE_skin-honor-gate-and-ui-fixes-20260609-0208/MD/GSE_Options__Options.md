# GSE_Options/Options.lua

**Role in this changeset:** Wires the user's Native/Modern toggle to the new honor-gate, and replaces a buggy live-skin-swap with a clean reload prompt.

**Lines:** 3076 → 3095 (+19)
**Hunks:** 3
**Severity:** Medium (fixes a "skin swap drops frames" defect and an unwanted forced-skin on a settings button)

---

## What changed

### Hunk 1 — `SkinGSESettingsButton(button)` (line ~232)

Added an early-out so the function respects the user's skin choice:

```lua
if GSE.ShouldHonorExternalSkin and not GSE.ShouldHonorExternalSkin() then return end
```

In Native mode this leaves the settings button on Blizzard's default look
instead of force-applying ElvUI's button skin. The `GSE.ShouldHonorExternalSkin and`
guard keeps it nil-safe if the API file hasn't loaded yet.

### Hunks 2 & 3 — the Native and Modern checkbox `SetValue` handlers (lines ~1369 and ~1396)

Both halves of the exclusive Native/Modern pair were rewritten the same way.

**Before** — flipped `UseModernSkin` and tried to live-swap the menu logo:

```lua
GSEOptions.UseModernSkin = val ~= true        -- (Native handler)
RefreshExclusiveOptionRows("skin")
if GSE.GUI and GSE.GUI.RefreshMenuLogo then GSE.GUI.RefreshMenuLogo() end
```

**After** — computes old/new state, prompts for reload *only when the skin
actually flips*, then records the new value (no live swap):

```lua
local wasModern = (GSEOptions.UseModernSkin == true)
local nowModern = (val ~= true)              -- (val == true) in the Modern handler
if nowModern ~= wasModern and GSE.GUIConfirmReloadUI then GSE.GUIConfirmReloadUI() end
GSEOptions.UseModernSkin = nowModern
RefreshExclusiveOptionRows("skin")
```

The two checkbox tooltips were also rewritten to state the new behaviour,
e.g. the Native checkbox now reads (paraphrased): uses GSE's native Blizzard
skin, ignores ElvUI/EllesmereUI even when loaded, and a `/reload` fully
repaints any already-open windows.

## Why it matters in current WoW

Re-skinning frames that are **already open** mid-session was dropping some of
them — the previous live-swap path repainted piecemeal and left windows in a
half-skinned or hidden state. Deferring to a `/reload` rebuilds **every** frame
in the new skin cleanly and all at once, which is the reliable path on Retail's
current frame/Settings model.

Guarding the prompt with `nowModern ~= wasModern` is important: the exclusive
checkbox pair fires `SetValue` on **both** the clicked and the unclicked box
during a panel sync/init, so an unguarded prompt would pop a spurious reload
dialog on the half that didn't actually change, or on first open.

## API / policy notes

- `GSE.GUIConfirmReloadUI` is defined in `GSE_GUI/NativeUI.lua` (verified at
  line 6182). Calling it is gated behind a nil-check, so a build that strips
  the GUI module won't error.
- `Settings.RegisterProxySetting` / `Settings.CreateCheckbox` usage is
  unchanged — these are the current Retail Settings API entry points.
- No combat/taint concern: this runs from a Settings panel interaction
  (hardware event) and only writes a saved-variable boolean + opens a
  reload-confirm popup.

## Verification

- `luac5.1 -p GSE_Options/Options.lua` → **PASS**
- `luacheck` → **21 warnings, identical to base** (no new issues from this diff)
- Cross-checked that `GSE.ShouldHonorExternalSkin` and `GSE.GUIConfirmReloadUI`
  both resolve to defined functions.

## Remaining risk / notes

- **Needs in-game verification:** confirm that toggling Native↔Modern shows
  exactly one reload prompt *only* when the value flips, and that selecting
  the already-active option produces no prompt. (Checklist item — headline UX.)
- The reload prompt is the intended UX, but it does mean the skin no longer
  changes "instantly" in the panel; that is by design per the inline comment.
