# GSE/API/InitialOptions.lua

**Role in this changeset:** Foundation. Adds the single source of truth that every other skin-related change in this build keys off.

**Lines:** 536 → 553 (+17)
**Hunks:** 1
**Severity:** Low (additive; no existing behavior touched)

---

## What changed

A new function was added immediately after `ShouldUseModernSkin()`:

```lua
function GSE.ShouldHonorExternalSkin()
    return GSE.ShouldUseModernSkin()
end
```

It is a thin alias of `ShouldUseModernSkin()`, but it gives the skin
dispatcher and every paint site a *named, intention-revealing* gate to
consult instead of re-deriving the modern/native decision inline.

The accompanying comment block documents the contract:

- **Native Skin** (`UseModernSkin == false`) → returns **false**: external
  providers (ElvUI / EllesmereUI) are **ignored even when loaded**. The GUI
  stays 100% Blizzard-native.
- **Modern Skin** (`UseModernSkin == true`) → returns **true**: GSE adopts the
  host UI's skin if present, otherwise falls back to GSE's own modern theme.

The user's `Native` checkbox drives `UseModernSkin`, so the user's choice
alone decides this — **addon presence never forces a skin on its own**.

## Why it matters in current WoW

Before this build, several UI sites checked `GSE.IsEllesmereUILoaded()`
directly and unconditionally re-coloured themselves to match EllesmereUI
whenever that addon was present. That meant a player who explicitly chose
GSE's Native skin still got EUI-tinted text/borders merely because EUI was
installed — the user's choice was being overridden by addon detection.

Centralising the decision here lets the call sites change from "is EUI
loaded?" to "should I honour an external skin *given the user's choice*?"
This is the linchpin for the gating added in `Skin.lua`, `Editor.lua`,
`Editor_Tree.lua`, and `Options.lua`.

## API / policy notes

- Pure Lua function definition on the `GSE` table. No Blizzard API surface
  involved, no taint/secure considerations.
- Every consumer calls it defensively as `(not GSE.ShouldHonorExternalSkin or GSE.ShouldHonorExternalSkin())`,
  so load-order races (a paint site firing before this file loads) fall back
  to "honour external" rather than erroring on a nil call. Safe on all
  target clients.

## Verification

- `luac5.1 -p GSE/API/InitialOptions.lua` → **PASS**
- `luacheck` → **0 warnings** (unchanged from base; no new globals/unused/shadowing)
- Confirmed all four downstream consumers resolve to a defined function:
  `Skin.lua` (selectProvider), `Editor.lua` (keywordColor), `Editor_Tree.lua`
  (×2), `Options.lua` (SkinGSESettingsButton).

## Remaining risk / notes

None. Lowest-risk change in the set. The only thing to keep in mind is that
because it is a *direct* alias, the two concepts (`ShouldUseModernSkin` and
`ShouldHonorExternalSkin`) are intentionally welded together — if a future
build ever wants "modern GSE theme but still ignore host UIs," this alias
would need to split into two independent flags.
