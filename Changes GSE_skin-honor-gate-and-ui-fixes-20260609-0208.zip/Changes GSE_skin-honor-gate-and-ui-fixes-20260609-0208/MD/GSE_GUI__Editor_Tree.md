# GSE_GUI/Editor_Tree.lua

**Role in this changeset:** Two more honor-gate sweep sites — resource-frame text colour and the tree title colour.

**Lines:** 1723 → 1727 (+4)
**Hunks:** 2
**Severity:** Low (colour-only; part of the consistent honor-gate sweep)

---

## What changed

### Hunk 1 — `SetResourceFrameTextColor(text, color)` (line ~122)
```lua
-- EUI-neutral-white only in Modern mode; Native keeps the GSE colour
-- even when EllesmereUI is loaded.
if (not GSE.ShouldHonorExternalSkin or GSE.ShouldHonorExternalSkin())
    and GSE.IsEllesmereUILoaded and GSE.IsEllesmereUILoaded() then
    text:SetTextColor(1, 1, 1, 1)
else
    text:SetTextColor(unpack(color))
end
```

### Hunk 2 — tree title colour (line ~359)
The same gate applied to the title fontstring:
```lua
if (not GSE.ShouldHonorExternalSkin or GSE.ShouldHonorExternalSkin())
    and GSE.IsEllesmereUILoaded and GSE.IsEllesmereUILoaded() then
    title:SetColor(1, 1, 1, 1)
else
    title:SetColor(unpack(RESOURCE_GOLD))
end
```

Both previously checked only `IsEllesmereUILoaded()` and forced white. Now the
EUI-white treatment is confined to Modern mode; in Native mode the resource
text keeps its GSE colour and the title keeps `RESOURCE_GOLD`, even when EUI is
installed.

## Why it matters in current WoW

Identical motivation to the `Editor.lua` / `Skin.lua` gates: a player who chose
GSE's Native skin should not get EllesmereUI's neutral-white text simply
because EUI is loaded. These two sites were leaking the override on the
resource frame and the tree title.

## API / policy notes

- `unpack(color)` / `SetTextColor` / `SetColor` — standard widget API,
  unchanged. The colour tables (`color`, `RESOURCE_GOLD`) are pre-existing.
- Nil-safe via the `not GSE.ShouldHonorExternalSkin or ...` short-circuit.
- No secure/taint surface.

## Verification

- `luac5.1 -p GSE_GUI/Editor_Tree.lua` → **PASS**
- `luacheck` → **19 warnings, identical to base** (no new issues from this diff)

## Remaining risk / notes

None of note. Lowest-risk file alongside `InitialOptions.lua`. Visual-only;
confirm resource text and tree title colour in both Native and Modern modes
with EllesmereUI loaded.
