# Events.lua — per-file detail

**File:** `GSE_Utils/Events.lua`
**Change type:** edit — adds an event-driven cast tracker and rewrites the Casting
capture to use it; also carries the `ResolvePlayerCast` poll (now secondary) and
the Next Cast Retail-gating from the prior packages.
**Net effect:** the Casting column reports the player's in-progress
cast/channel/empower even though 12.0 withholds the spell name from
`UnitCastingInfo`.

---

## Why polling failed (confirmed by the in-game dump)

`/dump {UnitCastingInfo("player")}` → `[1]={}` (a secret value, nothing else
readable). So neither the name nor the spell ID could be read by polling
`UnitCastingInfo`/`UnitChannelInfo` at trace time.

## New: event-driven cast tracker (end of file)

```lua
GSE.PlayerCastSpellID = nil
if CreateFrame then
    local function spellIDFromCast(castGUID, spellID)
        if type(castGUID) == "string" then
            local parts = GSE.split(castGUID, "-")
            local id = parts and tonumber(parts[6])   -- spell ID lives in field 6
            if id then return id end
        end
        if spellID ~= nil and not (issecretvalue and issecretvalue(spellID)) then
            return tonumber(spellID)
        end
        return nil
    end
    local castFrame = CreateFrame("Frame")
    local function register(event)
        if castFrame.RegisterUnitEvent then castFrame:RegisterUnitEvent(event, "player")
        else castFrame:RegisterEvent(event) end
    end
    register("UNIT_SPELLCAST_START");  register("UNIT_SPELLCAST_STOP")
    register("UNIT_SPELLCAST_CHANNEL_START"); register("UNIT_SPELLCAST_CHANNEL_STOP")
    if GSE.GameMode and GSE.GameMode >= 11 then       -- EMPOWER is Retail-only (10.0+)
        register("UNIT_SPELLCAST_EMPOWER_START"); register("UNIT_SPELLCAST_EMPOWER_STOP")
    end
    castFrame:SetScript("OnEvent", function(_, event, unit, castGUID, spellID)
        if unit ~= "player" then return end
        if event == "UNIT_SPELLCAST_START"
            or event == "UNIT_SPELLCAST_CHANNEL_START"
            or event == "UNIT_SPELLCAST_EMPOWER_START" then
            GSE.PlayerCastSpellID = spellIDFromCast(castGUID, spellID)
        else
            GSE.PlayerCastSpellID = nil
        end
    end)
end
```

Key points:

- **Non-secret spell ID.** The cast GUID string carries the spell ID in field 6
  and is never secret — exactly what `GSE:UNIT_SPELLCAST_SUCCEEDED` already does.
  The raw `spellID` arg is used only as a fallback and only when `issecretvalue`
  says it isn't secret.
- **Latch on START, clear on STOP.** State persists for the whole cast duration,
  so any trace logged during the cast reports it. Instant casts fire no START, so
  the state stays nil and the column correctly shows idle.
- **Retail-gated EMPOWER.** Registering the EMPOWER events on a client that
  doesn't know them throws, so they're gated on `GSE.GameMode >= 11` (same check
  the Tracker uses). `RegisterUnitEvent` is used with a `RegisterEvent` fallback,
  mirroring the Tracker.
- **Own frame.** Independent of GSE's event dispatcher; doesn't disturb the
  existing `UNIT_SPELLCAST_SUCCEEDED` handler.

## Casting capture rewrite (in `TraceSequence`)

```lua
local castingspell, isCasting
if GSE.PlayerCastSpellID then                 -- primary: event-latched ID
    isCasting = true
    local castInfo = GSE.GetSpellInfo(GSE.PlayerCastSpellID)
    castingspell = castInfo and castInfo.name
end
if GSE.isEmpty(castingspell) then             -- secondary: poll (how it used to)
    local polledName, polledCasting = ResolvePlayerCast()
    if not GSE.isEmpty(polledName) then castingspell = polledName end
    if polledCasting then isCasting = true end
end
if not GSE.isEmpty(castingspell) then CastingOutput = "Casting " .. castingspell
elseif isCasting then CastingOutput = "Casting"
else CastingOutput = "Not actively casting anything else." end
```

`ResolvePlayerCast` (added previously) is retained as the secondary poll for
clients/states where `UnitCastingInfo` isn't withheld. `castingColor` is unchanged
and now colours the generic "Casting" case too.

## Carried over (unchanged)

- `ASSISTED_HIGHLIGHT_AVAILABLE` + Retail-gated Next Cast column and row value.

---

## Verification specific to this file

- `loadfile("Events.lua")` parses with no error (after CRLF normalisation).
- Event-flow model: START→named; STOP→idle; CHANNEL/EMPOWER→named; instant→idle;
  other unit→ignored; spell ID extracted from the GUID even when the arg is
  secret; unknown ID→generic "Casting".
- The combined diff reproduces this file byte-for-byte; CRLF preserved.
