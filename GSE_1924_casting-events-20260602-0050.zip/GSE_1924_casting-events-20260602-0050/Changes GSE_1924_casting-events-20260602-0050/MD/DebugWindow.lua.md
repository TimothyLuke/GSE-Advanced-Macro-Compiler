# DebugWindow.lua — per-file detail

**File:** `GSE_GUI/DebugWindow.lua`
**Change type:** edit (1 hunk) — carried over unchanged from the `debug-columns`
package; no new change in this revision.
**Net effect:** the fallback column list gates the **Next Cast** column to Retail,
matching the live `GSE.SequenceDebugColumns`.

This file is unaffected by the Casting-column event tracker (that work is entirely
in `Events.lua`); it is included here only so the package is a complete,
installable superset of the prior changes.

---

## Hunk — gate the fallback "Next Cast" entry

```lua
 local DEFAULT_DEBUG_COLUMNS = {
     ... 8 columns ...,
-    {label = "Casting", width = 112, min = 75},
-    {label = "Next Cast", width = 90, min = 70}
+    {label = "Casting", width = 112, min = 75}
 }
+if C_AssistedCombat and C_AssistedCombat.GetNextCastSpell then
+    DEFAULT_DEBUG_COLUMNS[#DEFAULT_DEBUG_COLUMNS + 1] = {label = "Next Cast", width = 90, min = 70}
+end
```

`CopyDebugColumns` builds the active columns from
`GSE.SequenceDebugColumns or DEFAULT_DEBUG_COLUMNS`; gating this fallback the same
way keeps them consistent. `DEBUG_COLUMN_SCHEMA_VERSION` is unchanged (4); extra
saved width/visibility indices are ignored, so returning users are handled
gracefully at 9 or 10 columns.

---

## Verification specific to this file

- `loadfile("DebugWindow.lua")` parses with no error.
- Retail → 10 columns; non-Retail → 9 (Next Cast absent), matching `Events.lua`.
- The combined diff reproduces this file byte-for-byte; CRLF preserved.
