# GSE/API/Events.lua

**Scope:** shared base — identical in all 9 snapshots. ~180 changed lines vs `657a37a`.
**Features:** UI-error muting **and** action-bar highlight verification
(the `abo-highlight-verified` namesake).

## 1. UI-error filtering / voice + lower-energy muting
New helpers driven by the `HideUIErrorFrame` / `MuteVoiceErrors` /
`MuteLowerEnergy` options (defaults set in `InitialOptions.lua`):
- `EnsureErrorMessageOptions()` — back-fills the option defaults.
- `IsAllowedUIError(err)` / `FilterUIErrorsFrame(self, event, id, err, …)` —
  suppress the red UI error text for filtered errors.
- `SetErrorSpeechMuted(muted)` / `SetLowerEnergyMuted(muted)` — mute the spoken
  error VO and the "not enough energy"-type errors.
- `GSE.ApplyErrorMessageOptions()` — applies the current option state.

## 2. Action-bar highlight verification
- `GSE.ActionBarSlotHasForeignAction(button)` — is there a non-GSE action in this slot?
- `reevaluateOverrideButtonState(buttonName, sequence)` / `reevaluateAllOverrideButtons()`
- `GSE:ACTIONBAR_SLOT_CHANGED()` + `GSE:RegisterEvent("ACTIONBAR_SLOT_CHANGED")` —
  re-verify highlight / override-button state when an action-bar slot changes, so
  the highlight reflects what's actually on the bar.

## Note
The slot-foreign-action check is reused by the `Storage.lua` icon-flicker fix.
