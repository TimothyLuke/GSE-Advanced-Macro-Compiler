# GSE/API/Storage.lua

**Scope:** shared base — identical in all 9 snapshots. ~6 changed lines vs `657a37a`.
**Feature:** icon-flicker fix (supports the highlight-verification work).

## Change
When repainting a GSE button's icon, first check
`GSE.ActionBarSlotHasForeignAction(_G[k])`: if the player has dropped a *real*
(foreign) action into that slot, **don't** overwrite its icon with the
sequence's spell icon. This matches the existing Blizzard-bar branch and
`getGSEButtonIcon`, and stops the icon from flickering between the GSE icon and
the dropped action's icon.
