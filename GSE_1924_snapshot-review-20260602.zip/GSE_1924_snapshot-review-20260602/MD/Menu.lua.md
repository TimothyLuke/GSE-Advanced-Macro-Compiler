# GSE_GUI/Menu.lua

**Scope:** **varies** — present in 8 of 9 snapshots (all except `macro-charcount`).
~5 changed lines vs `657a37a`. Diff: `10-center-scaling__Menu.diff`.
**Feature:** center-scaling (pairs with `InitialOptions.lua`).

## Change
After `frame:SetClampedToScreen(true)`, sets `frame.GSESkipScaleClamp = true`.

## Why
The toolbar already self-clamps via `SetClampedToScreen`, so GSE's own
post-`SetScale` clamp is redundant *and* harmful here: it permanently re-anchors
the frame, producing the scale-down "left jump". The flag tells the SetScale path
(in `InitialOptions.lua`) to skip GSE's clamp for this frame.
