# GSE_GUI/DebugWindow.lua

**Scope:** **varies** — 4 states (baseline + 3 stacked feature levels).

| Level | Present in | Diff |
|---|---|---|
| baseline (unchanged) | macro-charcount, center-scaling, scroll-speed | — |
| **L1** Casting column | abo-highlight-verified, casting-events | `20-debug__DebugWindow_L1-casting-col.diff` |
| **L2** + successful-cast fallback | help-spells-ooc-casting | `21-debug__DebugWindow_L2-cast-fallback.diff` |
| **L3** + column sort / reorder | debug-column-sort-move, options-dropdown-strata, b1153 | `22-debug__DebugWindow_L3-column-sort-move.diff` |

## L1 — Casting column
Adds a `{label = "Casting", …}` column to `DEFAULT_DEBUG_COLUMNS`, plus a
`"Next Cast"` column gated on `C_AssistedCombat.GetNextCastSpell` (Retail-only
Assisted Highlight). Kept in sync with `GSE.SequenceDebugColumns` (see
`GSE_Utils/Events.lua`).

## L2 — successful-cast fallback
`SUCCESSFUL_CAST_FALLBACK_WINDOW`, `MarkSuccessfulCastRow`,
`IsSuccessfulCastFallbackRow`: when a successful-cast event arrives, mark the
matching (or recent fallback) row and colour the Casting cell
`|cFF00D1FFCasting <name>|r`, resolving the spell name from spell info / ID text.

## L3 — column sort + reorder
Saved, reorderable, sortable columns: `CopyDebugColumnOrder` (merge saved order
with any new columns), `debugColumnOrder`, `activeDebugSort`,
`GetVisibleDebugColumnOrder`, `GetDebugColumnOrderPosition`,
`MoveDebugColumnBefore`. This is the most-merged DebugWindow and the one in the
integrated head.
