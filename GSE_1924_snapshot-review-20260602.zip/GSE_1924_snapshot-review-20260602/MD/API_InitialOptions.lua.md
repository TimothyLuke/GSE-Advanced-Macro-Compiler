# GSE/API/InitialOptions.lua

**Scope:** **varies** — 2 variants. ~15 lines (mute-defaults) / +28 lines (center-scaling).

| Part | Present in | Diff |
|---|---|---|
| Mute-defaults | **all 9** | `12-mute-defaults__InitialOptions_shared-all.diff` |
| center-scaling math | 8 of 9 (all except `macro-charcount`) | `14-center-scaling__InitialOptions.diff` |

## Mute-defaults (shared by all)
Adds defaults + nil-guards for `GSEOptions.HideUIErrorFrame`,
`MuteVoiceErrors`, `MuteLowerEnergy` (all default `true`). Consumed by the
error-muting engine in `API/Events.lua`.

## center-scaling (the SetScale math)
Captures the frame centre in **absolute screen pixels** (frame-local centre ×
old effective scale) *before* `SetScale`, then converts back to the new local
units after — so the window scales **about its centre** instead of drifting by
`newScale/oldScale` (right/up on grow, left/down on shrink). The post-scale
clamp is now skipped when `frame.GSESkipScaleClamp` is set (see `Menu.lua`):
GSE's clamp permanently re-anchors a frame that grew past a screen edge, which
was the cause of the toolbar's scale-down "left jump".

> `macro-charcount` has only the mute-defaults — it predates / branched before
> the center-scaling math.
