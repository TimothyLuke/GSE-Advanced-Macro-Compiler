# GSE_GUI/Editor_Macro.lua

**Scope:** shared base — identical in all 9 snapshots. ~8 changed lines vs `657a37a`.
**Feature:** macro character-counter (pairs with `Editor.lua`).

## Change
At the per-macro edit box, the length passed to `SetMacroCountText` is now
`GSE.GUI.GetCompiledMacroBodyLength(text)` (falling back to
`GSE.GetMacroEditorTextLength` only if the helper is missing) — so the box's
"X/255" indicator matches the over-limit trigger and what WoW enforces on the
slot, rather than the raw typed length.
