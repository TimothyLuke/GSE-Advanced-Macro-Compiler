# GSE_Utils/Events.lua

**Scope:** **varies** — changed in all 9 but in **4 variants**. This is the casting-detection engine behind the DebugWindow "Casting" column.

| Variant | Present in | Diff |
|---|---|---|
| v_abo | abo-highlight-verified | `30-casting__UtilsEvents_v_abo.diff` |
| v3 | macro-charcount, center-scaling, scroll-speed | (see by-snapshot diffs) |
| v_help | help-spells-ooc-casting, debug-column-sort-move, options-dropdown-strata, b1153 | `31-casting__UtilsEvents_v_help.diff` |
| **v_casting** | casting-events | `32-casting__UtilsEvents_v_casting.diff` |

## What it does
- `ASSISTED_HIGHLIGHT_AVAILABLE = C_AssistedCombat ~= nil and C_AssistedCombat.GetNextCastSpell ~= nil` —
  gates the "Next Cast" column so non-Retail clients don't get a permanently-empty column.
- Adds `{label = "Casting", …}` and `{label = "Next Cast", …}` to `SequenceDebugColumns`.
- `ResolvePlayerCast()` — resolves the player's in-progress cast/channel for the
  Casting column. Works around **WoW 12.0 withholding the spell *name*** from
  `UnitCastingInfo`/`UnitChannelInfo` in combat (secret value) by reading the
  spell **ID** and the never-secret **cast-bar ID** via a guarded `tryUnit(...)`
  helper; returns `(castName, isCasting)` so the column can report a cast even
  when the name can't be resolved. Type-guarded so a bad value can't blank every
  column.

## ⚠ Integration note
`casting-events` (**v_casting**, ~156 changed lines) is a *different, more
elaborate* implementation than the head's **v_help** (~101 lines). The integrated
`b1153`/`options-dropdown-strata` use **v_help**, so adopting `casting-events`
means reconciling its Events variant against the head — not a clean fast-forward.
