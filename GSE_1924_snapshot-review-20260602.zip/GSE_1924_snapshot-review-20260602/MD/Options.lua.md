# GSE_Options/Options.lua

**Scope:** **varies** — 2 variants.

| Variant | Present in | Diff |
|---|---|---|
| pre-strata | abo, macro, center, help, casting, scroll, debug | `40-options__Options_pre-strata.diff` |
| **options-dropdown-strata** | options-dropdown-strata, b1153 | `41-options-dropdown-strata__Options.diff` |

## pre-strata (in 7 snapshots)
Baseline Options work shared by the earlier snapshots (the common Options edits
that precede the strata fix).

## options-dropdown-strata (in 2)
Raises the Settings-panel **dropdown popouts to `TOOLTIP` strata** so they render
in front of the panel instead of behind it:
- `RaiseOptionsDropdownFrame` (SetFrameStrata "TOOLTIP", SetToplevel,
  FrameLevel +100), `RaiseVisibleOptionsDropdownChildren`,
  `RaiseKnownOptionsDropdownPopouts`, `QueueRaiseOptionsDropdownPopouts`,
  `HookOptionsDropdownWidget`, `RaiseOptionsDropdown`.
- `FrameHasButtonChildren` — structurally finds the **anonymous** `SelectionPopout`
  (a shown child frame whose children include Buttons) that the old name-only
  heuristic missed.
- `AddErrorMessageOptions` / `AddErrorToggle` — a new **"Error Messages"** section
  in the Blizzard Settings panel wiring up `HideUIErrorFrame` / `MuteVoiceErrors`
  / `MuteLowerEnergy`, plus a toolbar **frame-strata** dropdown.

> Per the bundled `Changes …/Summary.MD`, this supersedes two earlier strata
> attempts (`-0030` crashed on `string.lower` of a non-string `GetName()`;
> `-0100` stopped the crash but still rendered behind because it targeted the
> wrong field and missed the unnamed popout).
