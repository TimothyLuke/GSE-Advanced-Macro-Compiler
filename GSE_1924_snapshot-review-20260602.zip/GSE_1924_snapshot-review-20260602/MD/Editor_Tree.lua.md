# GSE_GUI/Editor_Tree.lua

**Scope:** **varies** — present in 7 of 9 (all except `macro-charcount`, `center-scaling`).
~10 changed lines vs `657a37a`. Diff: `11-scroll-speed__Editor_Tree.diff`.
**Feature:** scroll-speed.

## Change
Removes the hardcoded `if scroll.SetScrollStep then scroll:SetScrollStep(96) end`
(and the same on `contentcontainer`) from the editor panes.

## Why
The hardcoded step pinned each pane's `scrollStep`, so the **"Editor Scroll
Speed"** slider — which only updates the global `SCROLL_STEP` (NativeUI) — had no
effect on those panes. Dropping the per-area override lets the panes inherit the
live, Options-driven scroll speed.
