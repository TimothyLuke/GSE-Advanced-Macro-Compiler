# GSE/API/Native.lua

**Scope:** shared base — identical in all 9 snapshots. ~4 changed lines vs `657a37a`.
**Feature:** none (comment cleanup).

## Change
Comment-only. The Ace3 mixin note no longer lists `AceConsole` /
`:RegisterChatCommand` (now reads AceEvent / AceComm → `:RegisterEvent` /
`:SendMessage` / `:RegisterComm`).

## Note
This is a *partial* AceConsole cleanup. The current `1914-Gui-Only` HEAD commit
`228dbc7f` ("Remove AceConsole Reference") goes further — reconcile against HEAD
rather than treating this snapshot line as authoritative.
