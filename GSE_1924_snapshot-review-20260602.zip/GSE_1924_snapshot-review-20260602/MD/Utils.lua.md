# GSE_Utils/Utils.lua

**Scope:** **varies** — 2 variants.

| Variant | Present in | Diff |
|---|---|---|
| variant A | macro-charcount, center-scaling, scroll-speed | `13-toolbar__Utils_variantA.diff` |
| variant B | abo, help, casting, debug, options, b1153 | `13-toolbar__Utils_variantB.diff` |

**Feature:** toolbar / command-bar plumbing.

## Change
Toolbar enable + command-colour handling: reads `GSEOptions.CommandColour`,
toggles `GSEOptions.ToolbarEnabled` (default-on unless explicitly `false`), and
manages `GSEOptions.frameLocations.menu.open`. Variant B is the form carried by
the integrated head; variant A is the earlier form in the macro/center/scroll
sub-lineage.
