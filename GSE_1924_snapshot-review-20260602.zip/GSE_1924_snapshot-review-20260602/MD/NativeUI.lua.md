# GSE_GUI/NativeUI.lua

**Scope:** shared base — identical in all 9 snapshots. ~18 changed lines vs `657a37a`.
**Feature:** editor scrollbar fix.

## Change
Re-parents the macro editor's scrollbar from the inner scroll frame onto the
**outer** frame and re-anchors it (`TOPRIGHT`/`BOTTOMRIGHT` in the reserved
right-hand gutter, width `STYLE.scrollBarWidth`, frame level +5).

## Why
`UIPanelScrollFrameTemplate` parents the scrollbar to the inner scroll frame,
which has `SetClipsChildren(true)` (set to keep macro content bounded). That clip
mask was cutting the scrollbar off — so on the default skin the editor looked
like it had no main scrollbar (`applyModernSlimScrollBar` only re-anchors under
the ElvUI skin). Parenting onto the un-clipped outer frame makes it render.
