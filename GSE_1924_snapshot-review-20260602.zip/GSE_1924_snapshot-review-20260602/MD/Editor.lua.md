# GSE_GUI/Editor.lua

**Scope:** shared base — identical in all 9 snapshots. ~136 changed lines vs `657a37a`.
**Feature:** macro character-counter (the `macro-charcount` namesake).

## Change
The macro **"X/255" length indicator now reports the *compiled* body length**
instead of the raw typed text length. A new helper
`GSE.GUI.GetCompiledMacroBodyLength` is exposed and used by `SetMacroCountText`
at every call site (main editor box and the per-keypress/per-version paths).

## Why
The over-limit trigger (`UpdateMacroLimitState`) and WoW itself enforce the
*compiled* body length on the macro slot. The indicator previously counted raw
typed characters, so it could disagree with the over-limit state — the number
said "fine" while the macro was actually truncated, or vice-versa. Counting the
compiled body keeps the indicator, the over-limit trigger, and WoW's enforcement
in agreement. Falls back to the raw length only if the compiled-length helper
isn't loaded (partial install).
