# Editor_Tree.lua — per-file detail

**File:** `GSE_GUI/Editor_Tree.lua`
**Change type:** edit (2 hunks)
**Net effect:** the editor's two main scroll areas honour the Options
"Editor Scroll Speed" slider instead of a hardcoded 96 px/notch.

---

## Background

`NativeUI.lua`'s `ScrollFrame` widget computes its per-wheel-notch step as:

```lua
local step = math.max(1, self.scrollStep or SCROLL_STEP)
```

`SCROLL_STEP` is the global, slider-driven value (`GSE.GUI.SetScrollStep` updates
it; default 280). `self.scrollStep` is an optional per-widget override. The
Options slider only ever updates the global `SCROLL_STEP`, so any area that sets
`self.scrollStep` opts out of the slider.

This file set `self.scrollStep = 96` on the editor's two main scroll areas, so
`self.scrollStep or SCROLL_STEP` was always 96 and the slider did nothing.

## Hunk 1 — right-pane content scroll (`makeScrollableRightPane`)

```lua
 local scroll = UI:Create("ScrollFrame")
-if scroll.SetScrollStep  then scroll:SetScrollStep(96) end
+-- No per-area SetScrollStep here: inherit the live, Options-driven scroll
+-- speed (NativeUI SCROLL_STEP, set by the "Editor Scroll Speed" slider).
+-- A hardcoded step (was 96) pinned self.scrollStep, so the slider — which
+-- only updates the global SCROLL_STEP — had no effect on this pane.
 if scroll.SetListPadding then
```

## Hunk 2 — macro-block list scroll (`editframe.scrollContainer`)

```lua
 local contentcontainer = UI:Create("ScrollFrame")
-if contentcontainer.SetScrollStep then contentcontainer:SetScrollStep(96) end
+-- No per-area SetScrollStep here: inherit the live, Options-driven scroll
+-- speed (NativeUI SCROLL_STEP, set by the "Editor Scroll Speed" slider).
+-- A hardcoded step (was 96) pinned self.scrollStep, so the slider — which
+-- only updates the global SCROLL_STEP — had no effect on the block list.
 scrollcontainer:AddChild(contentcontainer)
```

With both overrides gone, `self.scrollStep` stays `nil` on these widgets and the
step falls through to the global `SCROLL_STEP`. `MoveScroll` reads `SCROLL_STEP`
every notch, so slider changes take effect immediately on an open editor.

---

## Verification specific to this file

- `loadfile("Editor_Tree.lua")` parses with no error.
- Runtime-path model sweeping slider values 50→800: before, the editor step is 96
  for every value; after, it equals the slider value, and a live move to 420
  updates an already-open editor's step to 420.
- Grep confirms no hardcoded `SetScrollStep(...)` remains on any editor scroll area.
- The combined diff reproduces this file byte-for-byte; CRLF preserved.
