# Editor.lua — per-file detail

**File:** `GSE_GUI/Editor.lua`
**Change type:** edit (3 hunks)
**Net effect:** the "X/255" macro counter now reports the compiled body length —
the same value the over-limit trigger and WoW enforce.

---

## Background

Two length functions exist in this file:

- `GetCompiledMacroBodyLength(macroText)` (local, ~line 437) — compiles the macro
  via `GSE.CompileMacroText(..., Statics.TranslatorMode.String)` (which translates
  spell aliases to localized names and strips comment/empty lines), then
  un-escapes, decodes, and counts. This is the length WoW actually receives.
- The inline indicator `SetMacroCountText(box, lenMacro)` (~line 604) — just
  displays/recolours the number it is given; it does not compute length itself.

The **over-limit trigger** `UpdateMacroLimitState` (~line 520) uses
`GetCompiledMacroBodyLength`. The **counter** was being fed the *typed* length
(`GSE.GetMacroEditorTextLength` on the un-compiled text), so the two disagreed
whenever an alias expanded on compile.

---

## Hunk 1 — expose the compiled-length helper on `GSE.GUI`

Next to the existing exposures (`UpdateMacroLimitState`, `RefreshMacroLimitSaveState`,
`ForwardMacroEditorMouseWheel`, `SetMacroCountText`), expose the local
`GetCompiledMacroBodyLength` so the shared counter helper in `Editor_Macro.lua`
can use the identical computation:

```lua
GSE.GUI.GetCompiledMacroBodyLength = GetCompiledMacroBodyLength
```

A comment above it records *why* the counter must use this value (it must match
the trigger and WoW).

## Hunk 2 — initial-render counter (was ~line 5044)

Before — counted the visible/typed text and stored a dead `visible` local:

```lua
local visible = GSE.UnEscapeString(macroeditbox:GetText() or "")
SetMacroCountText(macroeditbox, GSE.GetMacroEditorTextLength(visible))
```

After — counts the compiled body; dead local removed; misleading comment replaced:

```lua
SetMacroCountText(macroeditbox, GetCompiledMacroBodyLength(macroeditbox:GetText() or ""))
```

`GetCompiledMacroBodyLength` decodes + un-escapes internally, so passing the raw
(possibly colour-coded) edit-box text is correct.

## Hunk 3 — live `OnTextChanged` counter (was ~line 7176)

Before — typed length, on a line directly above the trigger that uses the
compiled length:

```lua
SetMacroCountText(macroEditBox, GSE.GetMacroEditorTextLength(value or ""))
UpdateMacroLimitState(macroEditBox, sequence.Versions[version].Actions[keyPath].macro, editframe, version)
```

After — the counter is fed the **same** stored macro the trigger uses, so they
are computed from one source and cannot drift:

```lua
SetMacroCountText(macroEditBox, GetCompiledMacroBodyLength(sequence.Versions[version].Actions[keyPath].macro))
UpdateMacroLimitState(macroEditBox, sequence.Versions[version].Actions[keyPath].macro, editframe, version)
```

This handler already calls `GSE.CompileMacroText` every keystroke (for the
side-panel) and again inside `UpdateMacroLimitState`, so computing the compiled
length for the counter adds no new per-keystroke work.

---

## Verification specific to this file

- `loadfile("Editor.lua")` parses with no error.
- Grep confirms all `SetMacroCountText(...)` call sites in this file now pass
  `GetCompiledMacroBodyLength(...)` (no remaining `GetMacroEditorTextLength`
  argument to the counter).
- The combined diff reproduces this file byte-for-byte; CRLF line endings preserved.
- Boundary check via the real functions: 255 → not over (counter not red,
  trigger off); 256 → over (counter red, trigger on).
