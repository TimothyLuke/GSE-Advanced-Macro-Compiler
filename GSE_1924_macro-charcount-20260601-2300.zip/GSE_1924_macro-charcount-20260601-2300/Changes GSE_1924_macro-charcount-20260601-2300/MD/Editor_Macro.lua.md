# Editor_Macro.lua — per-file detail

**File:** `GSE_GUI/Editor_Macro.lua`
**Change type:** edit (1 hunk)
**Net effect:** the shared macro-counter helper now reports the compiled body
length, matching the over-limit trigger.

---

## What this file does here

`SetMacroTextCounter(widget, text)` is the shared helper that keeps a macro edit
box's "X/255" indicator and its over-limit state in sync. It calls two exposed
GUI helpers back to back:

- `GSE.GUI.SetMacroCountText(widget, <length>)` — the displayed counter.
- `GSE.GUI.UpdateMacroLimitState(widget, text)` — the over-limit trigger, which
  internally uses the **compiled** body length (`GetCompiledMacroBodyLength`).

The counter was being given the **typed** length while the trigger used the
**compiled** length — the same divergence as in `Editor.lua`.

## The hunk

Before:

```lua
if GSE.GUI and GSE.GUI.SetMacroCountText then
    GSE.GUI.SetMacroCountText(widget, GSE.GetMacroEditorTextLength(text or ""))
end
```

After — prefer the compiled-length helper now exposed by `Editor.lua`, with a
safe fallback to the typed-length count if it isn't loaded (e.g. a partial
install where `Editor.lua`'s exposure hasn't run):

```lua
if GSE.GUI and GSE.GUI.SetMacroCountText then
    local lenMacro = (GSE.GUI.GetCompiledMacroBodyLength and GSE.GUI.GetCompiledMacroBodyLength(text or ""))
        or GSE.GetMacroEditorTextLength(text or "")
    GSE.GUI.SetMacroCountText(widget, lenMacro)
end
```

The `UpdateMacroLimitState` call below is unchanged; now both the counter and the
trigger use the compiled length, so they agree.

---

## Verification specific to this file

- `loadfile("Editor_Macro.lua")` parses with no error.
- The fallback is guarded by `GSE.GUI.GetCompiledMacroBodyLength and ...`, so a
  lite install without the exposure still works (degrades to the old behaviour
  rather than erroring).
- The combined diff reproduces this file byte-for-byte; CRLF line endings preserved.
